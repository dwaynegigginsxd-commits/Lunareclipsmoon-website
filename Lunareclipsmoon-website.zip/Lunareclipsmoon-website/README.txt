LUNARECLIPSEMOON WEBSITE

Contents
- index.html: responsive single-page website
- images/lunareclipsemoon-logo.jpg: cropped brand header from your supplied mockup

Preview locally
1. Extract this ZIP.
2. Open index.html in Chrome.

Publish with Netlify
1. Sign in at https://app.netlify.com/
2. Choose Add new site -> Import an existing project.
3. Connect GitHub and choose dwaynegigginsxd-commits/Lunareclipsmoon-website.
4. Build command: leave blank.
5. Publish directory: .
6. Select Deploy.

GitHub upload note
The connected GitHub integration refused write access (HTTP 403), so these files have NOT been pushed to your repository. You can upload them manually:
1. Open https://github.com/dwaynegigginsxd-commits/Lunareclipsmoon-website
2. Choose Add file -> Upload files.
3. Upload index.html and the images folder contents, then commit to main.

Before launch
- Replace the placeholder social links with your real channel URLs.
- Add your confirmed stream schedule.
- The original mockup contained a revealing character illustration, so this package uses only the logo/header crop and a CSS eclipse illustration.
